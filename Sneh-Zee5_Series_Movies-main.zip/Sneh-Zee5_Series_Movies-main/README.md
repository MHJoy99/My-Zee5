<p align="center"><img src="https://www.pngkit.com/png/full/353-3536377_with-all-this-content-available-in-one-place.png" ></p>

<h1 align="center"> ⚒ ZEE5 STREAM SCRAPPER 🔐 </h1>

<p align="center"> It can Scrap Premium ZEE5 Movies , Series and TV Shows Using URL</p>

<h2> How To Use : </h2>

<h4>
♢ Go on <a href="https://www.zee5.com/">ZEE5 Site </a> There You Can Go Any Where What you want Scrap and Click There <br><br>
♢ Click On Episode / Movie / Shows Which You Want Scrap <br><br>
♢ And Just Copy URL From URL Box <br><br>
♢ e.g --> I Use This Link :<br><br>
  
```py
  https://www.zee5.com/movies/details/watch-uri-the-surgical-strike-full-movie-online/0-0-33204
```
 
♢ After Copy Paste URL after this URL : <br><code>http://snehzee5.ueuo.com/?c=</code> 
  <br><br>
  
♢ SERIES URL --> <br>
  
```py
  http://snehzee5.ueuo.com/?c=https://www.zee5.com/tvshows/details/bhabi-ji-ghar-par-hai/0-6-199/bhabi-ji-ghar-par-hai-july-20-2021/0-1-manual-31jmf0vqirgg
```

♢ MOVIES URL --> <br>

```py
  http://snehzee5.ueuo.com/?c=https://www.zee5.com/movies/details/watch-uri-the-surgical-strike-full-movie-online/0-0-33204
```

♢ WEBSERIES URL --> <br>

```py
  http://snehzee5.ueuo.com/?c=https://www.zee5.com/zee5originals/details/abhay/0-6-1298/ep-1-brain-soup/0-1-387043
```

♢ Run Final URL in Browser You Get Streaming URL <br>
</h4>
<br>



<h2> Where To Host : </h2>

<h5 align="center"> Copy The index.php code and Host on repl.it or heroku as your wish <br> or Your Hosting Otherwise Use http://snehzee5.ueuo.com/
<br>
  
---
<h5 align='center'>© 2021 TechieSneh</h5>

